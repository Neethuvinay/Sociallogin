<!DOCTYPE html>
<html>
<head>
	<title>SOCIAL LOGIN</title>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<?php 

if(isset($_GET['success']))

{
	if($_GET['success']==1){
?>
<script type="text/javascript">
	alert("Successfully Saved");
</script>
 <?php
}
 else
 {
 	?>
<script type="text/javascript">
	alert("Error Found");
</script>
 <?php }
}

	include 'db.php';
if (isset($_GET['user_id'])) {
$user_id=$_GET['user_id'];
	$query="SELECT * FROM `users` WHERE `user_id`=$user_id";
    $result=mysqli_query($conn,$query);
if(isset($result))

{
	$row=mysqli_fetch_assoc($result);
	$name=$row['user_name'];
	$email=$row['user_email'];
	$dob=$row['user_dob'];
	$education=$row['user_education'];
	$country=$row['user_country'];
	$city=$row['user_city'];
	$pin=$row['user_pin'];
	$address=$row['user_address'];
	$userid=$row['user_id'];
	
	$pic=$row['user_pic'];
	$status=$row['user_status'];
}



 }




 ?>


	<section class="userform">

	<div class="container ">
		   <div class="links">
      
      <a class="btn btn-primary" href="index.php">DASHBOARD</a>
      <a class="btn btn-success" href="list_users.php">LIST USERS</a>
      <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
		<div class="row">
			<div class="col-lg-10">
<form  id="userform" method="POST" action="user-process.php" enctype="multipart/form-data">
	<div class="row">
	 <div class="form-group col-lg-6 ">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Full Name" id="name" name="name" value="<?php if(isset($name)) echo $name; ?>" required>
   <input type="hidden" name="userid" value="<?php if(isset($userid)) echo $userid; ?>">
  </div>
  <div class="form-group col-lg-6">
    <label for="exampleInputEmail1">Email ID</label>
    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Email ID" name="email" value="<?php if(isset($email)) echo $email; ?>" required>
   
  </div>
 
 

  <div class="form-group col-lg-6 ">
    <label for="exampleInputEmail1">Dob</label>
    <input type="date" class="form-control" id="dob" aria-describedby="emailHelp" placeholder="Dob" name="dob" value="<?php if(isset($dob)) echo $dob; ?>" required>
   
  </div>
  <div class="form-group col-lg-6">
    <label for="exampleInputEmail1">Address</label>
    <textarea  class="form-control" id="address" aria-describedby="emailHelp" placeholder="Address" name="address" required><?php if(isset($address)) echo $address; ?></textarea>
   
  </div>
 
  <div class="form-group col-lg-6 ">
    <label for="exampleInputEmail1">Education</label>
    <input type="text" class="form-control" id="education" aria-describedby="emailHelp" placeholder="Education" name="education" value="<?php if(isset($education)) echo $education; ?>" required>
   
  </div>
  
 
  <div class="form-group col-lg-6 ">
    <label for="exampleInputEmail1"  >Country</label>
   <select  class="form-control country" id="country" name="country" required>
                    <option value="">Select</option>
                    <option value="usa" <?php if(isset($country) && $country=='usa') echo "selected"; ?>>United States</option>
                    <option value="india" <?php if(isset($country) && $country=='india') echo "selected"; ?>>India</option>
                    <option value="uk" <?php if(isset($country) && $country=='uk') echo "selected"; ?>>United Kingdom</option>
                </select> 
   
  </div>
  <div class="form-group col-lg-6">
    <label for="exampleInputEmail1">City</label>
 
  

  <select id="city" class="form-control" name="city"><option value="<?php if(isset($city)) echo $city; else echo "" ?>"><?php if(isset($city)) echo $city; else echo "Select"; ?></option></select>
   </div>
 
  <div class="form-group col-lg-6">
    <label for="exampleInputEmail1">Pin Code</label>
    <input type="text" class="form-control" id="pin" aria-describedby="emailHelp" placeholder="Pin code" name="pin" value="<?php if(isset($pin)) echo $pin; ?>" required>
   
  </div>
 
  <div class="form-group col-lg-6">
    <label for="exampleInputEmail1">Profile Pic</label>
    <input type="file" class="form-control" id="pic" aria-describedby="emailHelp" placeholder="Upload Profile Pic" name="pic" >
   <?php 
if(isset($pic))
	echo "<img src=uploads/$pic width=50 height=50>";
    ?>
  </div>

  <div class="form-group col-lg-6 ">
    <label for="exampleInputEmail1">Status</label><br>

    <input type="radio"  name="status" aria-describedby="emailHelp" value="1" <?php if(isset($status) && $status==1) echo "checked"; ?>/>  <label for="exampleInputEmail1" >Active</label>
    <input type="radio" name="status" aria-describedby="emailHelp" value="0" <?php if(isset($status) && $status==0) echo "checked"; ?>/>  <label for="exampleInputEmail1" >In Active</label>
   
  </div>
   <div class="form-group col-lg-6">
 <button type="submit" class="btn btn-primary" name="savebtn" id="savebtn">Submit</button>
   
  </div>
 
  
</form>

</div></div>
		</div>
	</div>
</section>
<script>
$(document).ready(function(){
    $("select.country").change(function(){
        var selectedCountry = $(".country option:selected").val();
        $.ajax({
            type: "POST",
            url: "process-request.php",
            data: { country : selectedCountry } 
        }).done(function(data){
            $("#city").html(data);
        });
    });
    // $("#savebtn").click(function(){
    	
    //     var formdata=$('#userform').serialize();
    //     $.ajax({
    //         type: "POST",
    //         url: "process-request.php",
    //         data: formdata,
    //     }).done(function(data){
    //     	alert('successfully Saved');
    //         console.log(data);

    //     });
    // });
});
</script>
</body>
</html>