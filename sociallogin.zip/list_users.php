<?php 
include 'db.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>SOCIAL LOGIN</title>
	 <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js"></script>



  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="  
https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<?php 
if(isset($_GET['del_id']))
{
	$delid=$_GET['del_id'];
$sql="select user_pic from users where user_id=$delid";
	$res=mysqli_query($conn,$sql);
if($res)
	$row=mysqli_fetch_assoc($res);

		unlink('uploads/'.$row['user_pic']);
	$sql="DELETE FROM `users` WHERE `user_id`=$delid";
	$res=mysqli_query($conn,$sql);

	if($res)
	{
		
		?>
		<script type="">
			alert('USER DATA DELETED SUCESSFULLY');
		</script>
		<?php
	}
	else
	{
		?>
		<script type="">
			alert('ERROR FOUND');
		</script>
		<?php
	}
} ?>
<div class="container">
	  <div class="links">
      
      <a class="btn btn-primary" href="index.php">DASHBOARD</a>
      <a class="btn btn-success" href="add_user.php">ADD USER</a>
      <a href="logout.php" class="btn btn-danger">Logout</a></div>
	<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            	<th>SLNO</th>
                <th>Name</th>
                <th>Email</th>
                <th>Age</th>
                <th>Photo</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        
      <tbody>
      	<?php 
      	$sql="SELECT * FROM `users` order by user_id desc";
 $res=mysqli_query($conn,$sql);
 $i=1;
while ($row=mysqli_fetch_assoc($res)) {

?>
      	<tr>
	<td><?php 	echo $i; ?></td>

	<td><?php 	echo $row['user_name']; ?></td>
	<td><?php 	echo $row['user_email']; ?></td>
	<td><?php 	

# procedural
echo date_diff(date_create($row['user_dob']), date_create('today'))->y;


	?></td>
	<td><img src="<?php echo "uploads/".$row['user_pic'] ?>" width="50" height="50"></td>
	<td><?php if($row['user_status']==1) echo "Active"; else
	echo "InActive"; ?></td>
	<td>
		<a href="add_user.php?user_id=<?php echo $row['user_id']; ?>">EDIT</a>
		<a href="list_users.php?del_id=<?php echo $row['user_id']; ?>" onclick=" return confirm('Are you sure to delete this record ?')">DELETE</a>
		
	</td>
</tr>

<?php
$i++;
}

 ?> 
      </tbody>
    </table>

</div>

	<script type="text/javascript">
		$(document).ready(function() {
    $('#example').DataTable();
} );
	</script>
</body></html>