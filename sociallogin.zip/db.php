<?php 
$conn=mysqli_connect('localhost','root','','sociallogin');
if(!$conn)
{
	echo "DB ERROR";

}

 ?>