<?php
include('db.php');
if(isset($_POST["savebtn"])){

$name=$_POST['name'];
$email  =$_POST['email'];
$dob=$_POST['dob'];
$address=$_POST['address'];
$status=$_POST['status'];
$userid=$_POST['userid'];

$education=$_POST['education'];
$country=$_POST['country'];
$city=$_POST['city'];
$pin=$_POST['pin'];
$target_dir = "uploads/";

  $imgname=rand(1,100).$_FILES["pic"]["name"];




    $target_file = $target_dir .$imgname;
if(!empty($_POST['userid']) )
{




$sqls="select user_pic from users WHERE user_id=$userid";

  $result=mysqli_query($conn,$sqls);

$row=mysqli_fetch_assoc($result);
if($_FILES['pic']['size'] !=0)
{

unlink('uploads/'.$row['user_pic']);
}
else
$imgname=$row['user_pic'];

$sql="UPDATE `users` SET `user_name`='".$name."',`user_email`='".$email."',`user_address`='".$address."',`user_dob`='".$dob."',`user_education`='".$education."',`user_pin`='".$pin."',`user_city`='".$city."',user_pic='".$imgname."',`user_country`='".$country."',`user_status`=$status WHERE user_id=$userid";
}
else
{

            $sql="INSERT INTO `users`( `user_name`, `user_email`, `user_address`, `user_dob`, `user_education`, `user_pin`, `user_pic`, `user_city`, `user_country`, `user_status`) VALUES ('".$name."','".$email."','".$address."','".$dob."','".$education."','".$pin."','".$imgname."','".$city."','".$country."',$status)";
          }

          if(isset($_FILES["pic"]))
move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);
         
            $res=mysqli_query($conn,$sql);
            if($res)
             header("Location:list_users.php?success=1");
            else
                   header("Location:list_users.php?success=0");
          

    }
    ?>