<?php

//config.php

//Include Google Client Library for PHP autoload file
require_once 'vendor/autoload.php';

//Make object of Google API Client for call Google API
$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('763343169391-p0jbf3q7o1akacdbtuuk0eovb9jsj1v9.apps.googleusercontent.com');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('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');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost/sociallogin/index.php');

//
$google_client->addScope('email');

$google_client->addScope('profile');

//start session on web page
session_start();

?>

